
/**
 * Write a description of class wordEditor3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
import java.io.*;
public class wordEditor3
{
   
}
